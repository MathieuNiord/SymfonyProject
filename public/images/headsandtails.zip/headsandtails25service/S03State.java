package headsandtails25service;
import headsandtails00random.CoinBasic;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Worker;
import miscellaneous.Miscellaneous;

public class S03State implements ChangeListener<Worker.State> {
  private final S01Button button ;
  private final S02Service service ;
  private final CoinBasic game ;
  public S03State (S01Button button, S02Service service, CoinBasic game) {
    this.button = button ;
    this.game = game ;
    this.service = service ;
  }
  @Override
  public void changed (ObservableValue<? extends Worker.State> observable,
                       Worker.State oldValue,
                       Worker.State newValue) {
    Miscellaneous.showStateChange (oldValue, newValue) ;
    switch (newValue) {
    case SUCCEEDED:
      this.button.setText (Miscellaneous.headsAndTailsString (game)) ;
      this.button.setDisable (false) ;
      this.service.reset () ;
      break ;
    case CANCELLED:
    case FAILED:
    case READY:
    case RUNNING:
    case SCHEDULED:
    }
  }
}