package headsandtails25service;
import headsandtails00random.CoinBasic;
import javafx.concurrent.Task ;
import javafx.concurrent.Service ;

public class S02Service extends Service<Long> {
  private final CoinBasic game ;
  private final long count ;
  public S02Service (CoinBasic game, S01Button button, long count) {
    super () ;
    this.game = game ;
    this.count = count ;
    this.stateProperty().addListener (new S03State (button, this, game)) ;
  }
  @Override protected Task<Long> createTask () {
    return new Task<Long> () {
      @Override protected Long call () throws Exception {
        S02Service.this.game
                .startLaunch (S02Service.this.count);
        return S02Service.this.game.getTails ();
      }
    } ;
  }
}