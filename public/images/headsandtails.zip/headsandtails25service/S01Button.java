package headsandtails25service;
import headsandtails10button.ButtonRaw;
import javafx.event.ActionEvent;

public class S01Button extends ButtonRaw {
  protected S02Service service;
  public S01Button (String buttonText, long throwCount) {
    super (buttonText, throwCount) ;
    this.init () ;
  }
  public S01Button (long throwCount) {
    super (throwCount) ;
    this.init () ;
  }
  public S01Button (String buttonText) {
    super (buttonText) ;
    this.init () ;
  }
  public S01Button () {
    super () ;
    this.init () ;
  }
  private void init () {
    this.service = new S02Service (randomCoin, this, throwCount) ;
  }
  @Override public void handle (ActionEvent event) {
    this.setDisable (true) ;
    this.setText (throwCount + RUNNING_BUTTON_TEXT) ;
    service.start () ;
  }
}