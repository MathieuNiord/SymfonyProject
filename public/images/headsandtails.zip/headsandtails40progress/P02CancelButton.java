package headsandtails40progress;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class P02CancelButton 
    extends Button implements EventHandler<ActionEvent> {

  protected P03Service service ;
  protected P01LaunchButton launchButton ;
  private final static String DEFAULT_TEXT = "Cancel" ;

  public P02CancelButton (String text, P01LaunchButton launchButton) {
    super (text) ;
    this.setOnAction (this) ;
    this.setDisable (true) ;
    this.launchButton = launchButton ;
    this.init (launchButton) ;
  }
  public P02CancelButton (P01LaunchButton launchButton) {
    this (DEFAULT_TEXT, launchButton) ;
    this.init (launchButton) ;
  }
  private void init (P01LaunchButton launchButton) {
    this.disableProperty().bind(Bindings.not(launchButton.disableProperty())) ;
  }
  protected P03Service getService () {
    return this.service ;
  }
  public void setLaunchButton (P01LaunchButton launchButton) {
    this.launchButton = launchButton ;
  }
  public P01LaunchButton getLaunchButton () {
    return this.launchButton ;
  }
  @Override public void handle (ActionEvent event) {
    this.getLaunchButton().getService().cancel() ;
    this.getLaunchButton().setDisable (false) ;
  }
}
