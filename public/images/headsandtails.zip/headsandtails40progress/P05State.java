package headsandtails40progress;
import headsandtails30cancel.C00Coin;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Worker;
import miscellaneous.Miscellaneous;

public class P05State implements ChangeListener<Worker.State> {
  private P01LaunchButton button ;
  private P03Service service ;
  private C00Coin game ;
  public P05State (P01LaunchButton button, P03Service service, C00Coin game) {
    this.button = button ;
    this.game = game ;
    this.service = service ;
  }
  @Override
  public void changed (ObservableValue<? extends Worker.State> observable,
                       Worker.State oldValue,
                       Worker.State newValue) {
    Miscellaneous.showStateChange (oldValue, newValue) ;
    switch (newValue) {
    case SUCCEEDED:
      this.button.textProperty().unbind() ;
      this.button.setText (Miscellaneous.headsAndTailsString (game)) ;
      this.button.setDisable (false) ;
      this.service.reset () ;
      break ;
    case CANCELLED:
      this.button.textProperty().unbind() ;
      this.button.setText ("Cancelled") ;
      this.button.setDisable (false) ;
      this.service.reset () ;
      break ;
    case FAILED:
      this.button.textProperty().unbind() ;
      break ;
    case READY:
      break ;
    case RUNNING:
      this.button.textProperty().bind(this.service.messageProperty()) ;
      break ;
    case SCHEDULED:
      break ;
    }
  }
}