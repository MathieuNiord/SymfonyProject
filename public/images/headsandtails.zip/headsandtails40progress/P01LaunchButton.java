package headsandtails40progress;
import headsandtails30cancel.C00Coin;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class P01LaunchButton 
    extends Button implements EventHandler<ActionEvent> {

  protected final static String INITIAL_BUTTON_TEXT = " Start coin throws " ;
  protected final static String RUNNING_BUTTON_TEXT = " coin throws" ;
  private final static long DEFAULT_THROW_COUNT = 100000 ;
  private final static long DEFAULT_THROW_PERIOD = 10000 ;

  protected P03Service service ;
  protected long throwCount ;
  protected long observePeriod ;
  protected C00Coin coin ;

  public P01LaunchButton (String buttonText, 
                          long throwCount, long observePeriod) {
    super (buttonText) ;
    this.throwCount = throwCount ;
    this.observePeriod = observePeriod ;
    this.setOnAction (this) ;
    this.coin = new C00Coin () ;
    this.coin.setShortDelay(500) ;
    this.init () ;
  }
  public P01LaunchButton (long throwCount) {
    this (INITIAL_BUTTON_TEXT, throwCount, DEFAULT_THROW_PERIOD) ;
    this.init () ;
  }
  public P01LaunchButton (String buttonText) {
    this (buttonText, DEFAULT_THROW_COUNT, DEFAULT_THROW_PERIOD) ;
    this.init () ;
  }
  public P01LaunchButton () {
    this (INITIAL_BUTTON_TEXT, DEFAULT_THROW_COUNT, DEFAULT_THROW_PERIOD) ;
    this.init () ;
  }
  private void init () {
    this.service = new P03Service (this.coin, this, 
                                   this.throwCount, this.observePeriod);
  }
  protected P03Service getService () {
    return this.service ;
  }
  @Override public void handle (ActionEvent event) {
    this.setDisable (true) ;
    this.setText (throwCount + RUNNING_BUTTON_TEXT) ;
    service.start () ;
  }
}
