package headsandtails40progress;
import headsandtails30cancel.C00Coin;
import javafx.concurrent.Task;
import miscellaneous.Miscellaneous;
public class P04Task extends Task<Long> {
  private final long throwCount ;
  private final long observePeriod ;
  private final C00Coin coin ;
  public P04Task (long count, long period, C00Coin coin) {
    super () ;
    this.throwCount = count ;
    this.observePeriod = period ;
    this.coin = coin ;
  }
  @Override protected Long call () throws Exception {
    long turns = throwCount / observePeriod ;
    long remainder = throwCount % observePeriod ;
    coin.reset () ;
    this.updateMessage (Miscellaneous.headsAndTailsString (coin)) ;
    coin.startLaunch (remainder);
    for (long i = 0 ; i < turns ; i++) {
      this.updateMessage (Miscellaneous.headsAndTailsString (coin)) ;
      if (this.isCancelled())
        break ;
      coin.restartLaunch (this.observePeriod) ;
    }
    return coin.getTails() ;
  }
}
