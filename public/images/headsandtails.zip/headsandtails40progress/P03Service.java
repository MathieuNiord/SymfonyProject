package headsandtails40progress;
import headsandtails30cancel.C00Coin;
import javafx.concurrent.Task ;
import javafx.concurrent.Service ;

public class P03Service extends Service<Long> {
  
  private final C00Coin game ;
  private final long throwCount ;
  private final long observePeriod ;
  public P03Service (C00Coin game, P01LaunchButton button,
                     long count, long period) {
    super () ;
    this.game = game ;
    this.throwCount = count ;
    this.observePeriod = period ;
    this.stateProperty().addListener (new P05State (button, this, game)) ;
  }
  @Override protected Task<Long> createTask () {
    P04Task task 
            = new P04Task (this.throwCount, this.observePeriod, this.game) ;
    return task ;
  }
}