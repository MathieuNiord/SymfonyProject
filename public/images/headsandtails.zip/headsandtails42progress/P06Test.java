package headsandtails42progress;
import javafx.application.Application;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;
import miscellaneous.BorderPaneWithQuit;

public class P06Test extends Application {
  private final static int N = 10 ;
  @Override public void start (Stage stage) {
    FlowPane pane = new FlowPane (Orientation.VERTICAL) ;
    P01LaunchButton launchButton
            = new P01LaunchButton ("Launch", 1000000, 100000) ;
    P02CancelButton cancelButton
            = new P02CancelButton ("Cancel", launchButton) ;
    pane.getChildren ().addAll (launchButton, cancelButton) ;
    pane.setAlignment (Pos.CENTER_LEFT) ;
    BorderPaneWithQuit root = new BorderPaneWithQuit() ;
    root.setCenter (pane) ;
    Scene scene = new Scene (root, 300, 300) ;
    stage.setTitle ("Throwing " + N + " dice") ;
    stage.setScene (scene) ;
    stage.show () ;
  }
  public static void main (String[] args) {
    launch (args) ;
  }
}
