package headsandtails42progress;
import headsandtails30cancel.C00Coin;
import javafx.application.Platform;
import javafx.concurrent.Task;
import miscellaneous.Miscellaneous;

public class P04Task extends Task<Long> {
  
  private final long throwCount ;
  private final long observePeriod ;
  private final C00Coin coin ;
  private final P01LaunchButton button ;
  
  public P04Task (long count, long period, 
                  C00Coin coin, P01LaunchButton button) {
    super () ;
    this.throwCount = count ;
    this.observePeriod = period ;
    this.coin = coin ;
    this.button = button ;
  }
  Runnable updateButton = new Runnable () {
      public void run () {
        P04Task.this.button.setText (Miscellaneous.headsAndTailsString (coin)) ;
      }} ;
  @Override protected Long call () throws Exception {
    long turns = throwCount / observePeriod ;
    long remainder = throwCount % observePeriod ;
    coin.reset () ;
    Platform.runLater (updateButton) ;
    coin.startLaunch (remainder);
    for (long i = 0 ; i < turns ; i++) {
      Platform.runLater (updateButton) ;
      coin.restartLaunch (this.observePeriod) ;
      if (this.isCancelled())
        break ;
    }
    return coin.getTails() ;
  }
}