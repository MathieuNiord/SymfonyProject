package headsandtails10button;

import javafx.application.Application;
import javafx.scene.layout.FlowPane ;
import javafx.geometry.Pos ;
import javafx.scene.Scene;
import javafx.stage.Stage;
import miscellaneous.BorderPaneWithQuit;

public class ButtonTest extends Application {
  @Override public void start (Stage stage) {
    FlowPane pane = new FlowPane () ;
    ButtonRaw button1 = new ButtonRaw ("Button 1", 10000) ;
    ButtonRaw button2 = new ButtonRaw ("Button 2", 10000) ;
    pane.getChildren ().addAll (button1, button2) ;
    pane.setAlignment (Pos.CENTER) ;
    BorderPaneWithQuit root = new BorderPaneWithQuit() ;
    root.setCenter (pane) ;
    Scene scene = new Scene (root, 300, 300) ;
    stage.setTitle ("Throwing two dice (02)") ;
    stage.setScene (scene) ;
    stage.show () ;
  }
  public static void main (String[] args) {
    System.out.println ("Beginning of main from Application") ;
    launch (args) ;
    System.out.println ("End of main from Application") ;
  }
}