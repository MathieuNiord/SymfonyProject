package headsandtails10button;
import headsandtails00random.CoinBasic;
import javafx.scene.control.Button;
import javafx.event.ActionEvent ;
import javafx.event.EventHandler ;
import miscellaneous.Miscellaneous;

public class ButtonRaw
  extends Button implements EventHandler<ActionEvent> {

  protected final static String INITIAL_BUTTON_TEXT = " Start coin throws " ;
  protected final static String RUNNING_BUTTON_TEXT = " coin throws" ;
  private final static long DEFAULT_THROW_COUNT = 100000 ;

  protected long throwCount ;
  protected CoinBasic randomCoin;

  public ButtonRaw (String buttonText, long throwCount) {
    super (buttonText) ;
    this.throwCount = throwCount ;
    this.setOnAction (this) ;
    this.randomCoin = new CoinBasic () ;
  }
  public ButtonRaw (long throwCount) {
    this (INITIAL_BUTTON_TEXT, throwCount) ;
  }
  public ButtonRaw (String buttonText) {
    this (buttonText, DEFAULT_THROW_COUNT) ;
  }
  public ButtonRaw () {
    this (INITIAL_BUTTON_TEXT, DEFAULT_THROW_COUNT) ;
  }
  @Override public void handle (ActionEvent event) {
    this.setDisable (true) ;
    this.setText (throwCount + RUNNING_BUTTON_TEXT) ;
    this.randomCoin.startLaunch (throwCount) ;
    this.setText (Miscellaneous.headsAndTailsString (randomCoin)) ;
    this.setDisable (false) ;
  }
}