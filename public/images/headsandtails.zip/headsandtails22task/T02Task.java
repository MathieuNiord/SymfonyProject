package headsandtails22task;
import headsandtails00random.CoinBasic;
import javafx.concurrent.Task;

public class T02Task extends Task<Long> {
  private final CoinBasic game ;
  private final long count ;
  public T02Task (CoinBasic game, T01Button button, long count) {
    super () ;
    this.game = game ;
    this.count = count ;
    this.stateProperty().addListener (new T03State (button, game)) ;
  }
  @Override protected Long call () throws Exception {
    this.game.startLaunch (this.count) ;
    return this.game.getTails() ;
  }
}