package headsandtails22task;
import headsandtails00random.CoinBasic;
import javafx.concurrent.Worker;
import javafx.beans.value.ChangeListener ;
import javafx.beans.value.ObservableValue ;
import miscellaneous.Miscellaneous;

public class T03State implements ChangeListener<Worker.State> {
  private final T01Button button ;
  private final CoinBasic game ;
  public T03State (T01Button button, CoinBasic game) {
    this.button = button ;
    this.game = game ;
  }
  @Override public void 
        changed (ObservableValue<? extends Worker.State> observable,
                 Worker.State oldValue,
                 Worker.State newValue) {
    Miscellaneous.showStateChange (oldValue, newValue) ;
    switch (newValue) {
    case SUCCEEDED:
      this.button.setText (Miscellaneous.headsAndTailsString (game)) ;
      this.button.setDisable (false) ;
      break ;
    case CANCELLED:
    case FAILED:
    case READY:
    case RUNNING:
    case SCHEDULED:
    }
  }
}