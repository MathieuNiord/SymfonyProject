package headsandtails22task;
import headsandtails10button.ButtonRaw;
import javafx.event.ActionEvent ;

public class T01Button extends ButtonRaw {
  private T02Task randomTask;
  private Thread randomThread;
  public T01Button (String buttonText, long throwCount) {
    super (buttonText, throwCount) ;
    this.init () ;
  }
  public T01Button (long throwCount) {
    super (throwCount) ;
    this.init () ;
  }
  public T01Button (String buttonText) {
    super (buttonText) ;
    this.init () ;
  }
  public T01Button () {
    super () ;
    this.init () ;
  }
  private void init () {
    this.randomTask = new T02Task (randomCoin, this, throwCount) ;
    this.randomThread = new Thread (randomTask) ;  
  }
  @Override
  public void handle (ActionEvent event) {
    this.setDisable (true) ;
    this.setText (throwCount + RUNNING_BUTTON_TEXT) ;
    try {
      randomThread.start () ;
    } catch (IllegalThreadStateException e) {
      System.out.println ("A terminated thread cannot be restarted") ;
      this.setText ("Button unavailable") ;
    }
  }
}