package miscellaneous;
import javafx.concurrent.Worker;

public class Miscellaneous {
  
  private final static int DEFAULT_COUNT_WIDTH = 6 ;
  public static String 
         headsAndTailsString (headsandtails00random.CoinBasic coin,
                             int width) {
    return String.format ("%0" + width + "d", coin.getHeads ())
           + " heads / "
           + String.format ("%0" + width + "d", coin.getTails ())
           + " tails" ;
  }
  public static String 
         headsAndTailsString (headsandtails00random.CoinBasic coin) {
    return headsAndTailsString (coin, DEFAULT_COUNT_WIDTH) ;
  }
  public static void showStateChange (Worker.State oldValue, 
                                      Worker.State newValue) {
    System.out.println (stringStateChange (oldValue, newValue)) ;
  }
  public static String stringStateChange (Worker.State oldValue, 
                                          Worker.State newValue) {
    return oldValue.toString() + " -> " + newValue.toString() ;
  }
  public static void main (String [] arg) {
    headsandtails00random.CoinBasic coin 
            = new headsandtails00random.CoinBasic () ;
    coin.startLaunch (10000) ;
    System.out.println (headsAndTailsString (coin)) ;
  }
}
