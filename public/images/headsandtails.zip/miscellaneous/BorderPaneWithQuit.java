package miscellaneous;
import javafx.scene.Scene ;
import javafx.application.Application ;
import javafx.application.Platform ;
import javafx.scene.control.Button ;
import javafx.scene.layout.BorderPane ;
import javafx.geometry.Pos ;
import javafx.stage.Stage ;
import javafx.event.ActionEvent ;
import javafx.event.EventHandler ;
public class BorderPaneWithQuit extends BorderPane {
  private final static String DEFAULT_TEXT = "Quit" ;
  public BorderPaneWithQuit (String text) {
    super () ;
    quitButton = new Button (text) ;
    BorderPane.setAlignment (quitButton, Pos.BOTTOM_RIGHT) ;
    this.setBottom (quitButton) ;
    quitButton.addEventHandler
      (ActionEvent.ACTION,
       new EventHandler<ActionEvent>() {
          @Override public void handle (ActionEvent event) {
            Platform.exit() ;
          }}) ;
  }
  public BorderPaneWithQuit () {
    this (DEFAULT_TEXT) ;
  }
  private Button quitButton ;
  
  public class MyApp extends Application {
    @Override public void start(Stage primaryStage) {
      BorderPaneWithQuit root = new BorderPaneWithQuit ("Quit");
      Scene scene = new Scene(root, 300, 200) ;
      primaryStage.setTitle("Devil's face");
      primaryStage.setScene(scene);
      primaryStage.show();
    }
  }
  public static void main (String[] args) {
    MyApp.launch(MyApp.class, args);
  }
}
