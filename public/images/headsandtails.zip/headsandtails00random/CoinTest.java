package headsandtails00random;
public class CoinTest {
  private final static long DEFAULT_COIN_THROWS = 50000 ;
  public static void main (String [] arg) {
    long coinThrows ;
    if (arg.length == 0) 
      coinThrows = DEFAULT_COIN_THROWS ;
    else
      coinThrows = Long.parseLong (arg[0]) ;
    CoinBasic randomCoin = new CoinBasic () ;
    randomCoin.startLaunch (coinThrows) ;
    System.out.println ("Coin throws: " + coinThrows) ;
    System.out.println ("Heads count: " + randomCoin.getHeads()) ;
    System.out.println ("Tails count: " + randomCoin.getTails()) ;
  }
}
