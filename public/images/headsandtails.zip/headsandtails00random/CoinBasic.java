package headsandtails00random;
import java.util.Random ;

public class CoinBasic {
  
  protected static final int DEFAULT_LONG_DELAY = 3000 ;
  private int delay ;
  
  public CoinBasic (int delay) {
    this.delay = delay ;
  }
  public CoinBasic () {
    this (DEFAULT_LONG_DELAY) ;
  }
  public void reset () {
    this.tails = 0 ;
    this.heads = 0 ;
  }
  public void startLaunch (long n) {
    this.reset () ;
    for (long i = 0 ; i < n ; i++) {
      if (generator.nextBoolean ())
        heads++ ;
      else
        tails++ ;
    }
    try {
      Thread.sleep (this.delay) ;
    } catch (Exception e) {
      // Just catch it!
    }
  }
  public long getHeads () {
    return this.heads ;
  }
  public long getTails () {
    return this.tails ;
  }
  public void setDelay (int delay) {
    this.delay = delay ;
  }
  public int getDelay () {
    return this.delay ;
  }
  protected long heads, tails ;

  protected static final Random generator ;
  static {
    generator = new Random () ;
  }
}