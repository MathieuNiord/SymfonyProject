package headsandtails21task;
import headsandtails10button.ButtonRaw;
import headsandtails00random.CoinBasic;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import javafx.event.ActionEvent ;
import miscellaneous.Miscellaneous;

public class T01Button extends ButtonRaw {
  private ComputingTask randomTask;
  public T01Button (String buttonText, long throwCount) {
    super (buttonText, throwCount) ;
    this.init () ;
  }
  public T01Button (long throwCount) {
    super (throwCount) ;
    this.init () ;
  }
  public T01Button (String buttonText) {
    super (buttonText) ;
    this.init () ;
  }
  public T01Button () {
    super () ;
    this.init () ;
  }
  private void init () {
    this.randomTask = new ComputingTask (randomCoin, throwCount) ;
  }
  @Override public void handle (ActionEvent event) {
    this.setDisable (true) ;
    this.setText (throwCount + RUNNING_BUTTON_TEXT) ;
    Thread myThread = new Thread (randomTask) ;
    myThread.start () ;
  }
  private class ComputingTask extends Task<Long> {
    private CoinBasic game ;
    private long count ;
    public ComputingTask (CoinBasic game, long count) {
      super () ;
      this.game = game ;
      this.count = count ;
      this.stateProperty()
              .addListener ((observable, oldValue, newValue) -> {
                if (newValue == Worker.State.SUCCEEDED) {
                  T01Button.this
                    .setText (Miscellaneous.headsAndTailsString (randomCoin)) ;
                  T01Button.this.setDisable (false) ;
            }}) ;
    }
    @Override protected Long call () throws Exception {
      this.game.startLaunch (this.count) ;
      return this.game.getTails() ;
    }
  }
}