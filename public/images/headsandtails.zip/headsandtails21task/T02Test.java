package headsandtails21task;

import javafx.application.Application;
import javafx.scene.layout.FlowPane ;
import javafx.geometry.Pos ;
import javafx.geometry.Orientation ;
import javafx.scene.Scene;
import javafx.stage.Stage;
import miscellaneous.BorderPaneWithQuit;

public class T02Test extends Application {
  private final static int N = 10 ;
  @Override public void start (Stage stage) {
    FlowPane pane = new FlowPane (Orientation.VERTICAL) ;
    T01Button[] button = new T01Button [N] ;
    for (int i = 1 ; i <= N ; i++) {
      button[i-1] = new T01Button ("Button " + i, 10000) ;
      
    }
    pane.getChildren ().addAll (button) ;
    pane.setAlignment (Pos.CENTER_LEFT) ;
    BorderPaneWithQuit root = new BorderPaneWithQuit() ;
    root.setCenter (pane) ;
    Scene scene = new Scene (root, 300, 300) ;
    stage.setTitle ("Throwing " + N + " dice") ;
    stage.setScene (scene) ;
    stage.show () ;
  }
  public static void main (String[] args) {
    launch (args) ;
  }
}