package headsandtails32cancel;
import javafx.concurrent.Task ;
import javafx.concurrent.Service ;
import headsandtails30cancel.C00Coin ;

public class C03Service extends Service<Long> {
  
  private final C00Coin game ;
  private final long throwCount ;
  private final long observePeriod ;
  
  public C03Service (C00Coin game, C01LaunchButton button, 
                     long throwCount, long observePeriod) {
    super () ;
    this.game = game ;
    this.throwCount = throwCount ;
    this.observePeriod = observePeriod ;
    this.stateProperty().addListener (new C05State (button, this, game)) ;
  }
  @Override protected Task<Long> createTask () {
    C04Task task 
            = new C04Task (this.throwCount, this.observePeriod, this.game) ;
    return task ;
  }
}