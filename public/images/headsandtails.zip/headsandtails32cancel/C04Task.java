package headsandtails32cancel;
import javafx.concurrent.Task;
import headsandtails30cancel.C00Coin ;

public class C04Task extends Task<Long> {
  private final long throwCount ;
  private final long observePeriod ;
  private final C00Coin coin ;
  public C04Task (long throwCount, long observePeriod, C00Coin coin) {
    super () ;
    this.throwCount = throwCount ;
    this.observePeriod = observePeriod ;
    this.coin = coin ;
  }
  @Override protected Long call () throws Exception {
    long turns = throwCount / observePeriod ;
    long remainder = throwCount % observePeriod ;
    coin.reset () ;
    coin.startLaunch (remainder);
    for (long i = 0 ; i < turns ; i++) {
      coin.restartLaunch (this.observePeriod) ;
      if (this.isCancelled())
        break ;
    }
    return coin.getTails() ;
  }
}
