package headsandtails32cancel;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class C02CancelButton 
    extends Button implements EventHandler<ActionEvent> {

  private final static String DEFAULT_TEXT = "Cancel" ;

  protected C03Service service ;
  protected C01LaunchButton launchButton ;

  public C02CancelButton (String text, C01LaunchButton launchButton) {
    super (text) ;
    this.setOnAction (this) ;
    this.setDisable (true) ;
    this.launchButton = launchButton ;
    this.init (launchButton) ;
  }
  public C02CancelButton (C01LaunchButton launchButton) {
    this (DEFAULT_TEXT, launchButton) ;
    this.init (launchButton) ;
  }
  private void init (C01LaunchButton launchButton) {
    this.disableProperty().bind(Bindings.not(launchButton.disableProperty())) ;
  }
  protected C03Service getService () {
    return this.service ;
  }
  public void setLaunchButton (C01LaunchButton launchButton) {
    this.launchButton = launchButton ;
  }
  public C01LaunchButton getLaunchButton () {
    return this.launchButton ;
  }
  @Override public void handle (ActionEvent event) {
    this.getLaunchButton().getService().cancel() ;
    this.getLaunchButton().setDisable (false) ;
  }
}