package headsandtails32cancel;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import headsandtails30cancel.C00Coin ;

public class C01LaunchButton 
    extends Button implements EventHandler<ActionEvent> {

  protected final static String INITIAL_BUTTON_TEXT = " Start coin throws " ;
  protected final static String RUNNING_BUTTON_TEXT = " coin throws" ;
  private final static long DEFAULT_THROW_COUNT = 100000 ;
  private final static long DEFAULT_THROW_PERIOD = 10000 ;

  protected C03Service service ;
  protected final long throwCount ;
  protected final long observePeriod ;
  protected final C00Coin coin ;

  public C01LaunchButton (String buttonText, 
                          long throwCount, long observePeriod) {
    super (buttonText) ;
    this.throwCount = throwCount ;
    this.observePeriod = observePeriod ;
    this.setOnAction (this) ;
    this.coin = new C00Coin () ;
    this.init () ;
  }
  public C01LaunchButton (long throwCount) {
    this (INITIAL_BUTTON_TEXT, throwCount, DEFAULT_THROW_PERIOD) ;
    this.init () ;
  }
  public C01LaunchButton (String buttonText) {
    this (buttonText, DEFAULT_THROW_COUNT, DEFAULT_THROW_PERIOD) ;
    this.init () ;
  }
  public C01LaunchButton () {
    this (INITIAL_BUTTON_TEXT, DEFAULT_THROW_COUNT, DEFAULT_THROW_PERIOD) ;
    this.init () ;
  }
  private void init () {
    this.service 
            = new C03Service (coin, this, this.throwCount, this.observePeriod);
  }
  protected C03Service getService () {
    return this.service ;
  }
  @Override public void handle (ActionEvent event) {
    this.setDisable (true) ;
    this.setText (throwCount + RUNNING_BUTTON_TEXT) ;
    service.start () ;
  }
}
