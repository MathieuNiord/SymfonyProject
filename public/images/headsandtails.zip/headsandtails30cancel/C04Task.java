package headsandtails30cancel;
import javafx.concurrent.Task;

public class C04Task extends Task<Long> {
  private final long throwCount ;
  private final long observePeriod ;
  private final C00Coin coin ;
  public C04Task (long throwCount, long observePeriod, C00Coin coin) {
    super () ;
    this.throwCount = throwCount ;
    this.observePeriod = observePeriod ;
    this.coin = coin ;
  }
  @Override protected Long call () throws Exception {
    long turns = throwCount / observePeriod ;
    long remainder = throwCount % observePeriod ;
    coin.reset () ;
    coin.startLaunch (remainder);
    for (long i = 0 ; i < turns ; i++) {
      if (this.isCancelled())
        break ;
      coin.restartLaunch (this.observePeriod) ;
    }
    return coin.getTails() ;
  }
}
