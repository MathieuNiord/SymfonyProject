package headsandtails30cancel;
import javafx.concurrent.Task ;
import javafx.concurrent.Service ;

public class C03Service extends Service<Long> {
  private final C00Coin game ;
  private final long count ;
  private C04Task task ;
  public C03Service (C00Coin game, C01LaunchButton button, long count) {
    super () ;
    this.game = game ;
    this.count = count ;
    this.stateProperty().addListener (new C05State (button, this, game)) ;
  }
  @Override protected Task<Long> createTask () {
    this.task = new C04Task (100000, 10000, this.game) ;
    return this.task ;
  }
}