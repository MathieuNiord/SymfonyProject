package headsandtails30cancel;

import javafx.application.Application;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;
import miscellaneous.BorderPaneWithQuit;

public class C06Test extends Application {
  @Override public void start (Stage stage) {
    FlowPane pane = new FlowPane (Orientation.VERTICAL) ;
    C01LaunchButton buttonLaunch
            = new C01LaunchButton ("Launch", 100000, 10000) ;
    C02CancelButton buttonCancel
            = new C02CancelButton ("Cancel") ;
    // Connect together the two buttons
    buttonCancel.setLaunchButton(buttonLaunch) ;
    buttonLaunch.setCancelButton(buttonCancel) ;
    // Done
    pane.getChildren ().addAll (buttonLaunch, buttonCancel) ;
    pane.setAlignment (Pos.CENTER_LEFT) ;
    BorderPaneWithQuit root = new BorderPaneWithQuit() ;
    root.setCenter (pane) ;
    Scene scene = new Scene (root, 300, 300) ;
    stage.setTitle ("Throw die and cancel task") ;
    stage.setScene (scene) ;
    stage.show () ;
  }
  public static void main (String[] args) {
    launch (args) ;
  }
}
