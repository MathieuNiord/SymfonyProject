package headsandtails30cancel;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class C02CancelButton 
    extends Button implements EventHandler<ActionEvent> {

  private final static String DEFAULT_TEXT = "Cancel" ;

  protected C03Service service ;
  protected C01LaunchButton launchButton ;

  public C02CancelButton (String text) {
    super (text) ;
    this.setOnAction (this) ;
    this.setDisable (true) ;
    this.init () ;
  }
  public C02CancelButton () {
    this (DEFAULT_TEXT) ;
    this.init () ;
  }
  private void init () {
  }
  protected C03Service getService () {
    return this.service ;
  }
  public void setLaunchButton (C01LaunchButton launchButton) {
    this.launchButton = launchButton ;
  }
  public C01LaunchButton getLaunchButton () {
    return this.launchButton ;
  }
  @Override public void handle (ActionEvent event) {
    this.setDisable (true) ;
    this.getLaunchButton().getService().cancel() ;
    this.getLaunchButton().setDisable (false) ;
  }
}
