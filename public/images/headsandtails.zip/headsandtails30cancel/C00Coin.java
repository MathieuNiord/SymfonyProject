package headsandtails30cancel;
public class C00Coin extends headsandtails00random.CoinBasic {
  private static final int DEFAULT_SHORT_DELAY = 200 ;
  public C00Coin (int longDelay, int shortDelay) {
    super (longDelay) ;
    this.shortDelay = shortDelay ;
  }
  public C00Coin () {
    this (DEFAULT_LONG_DELAY, DEFAULT_SHORT_DELAY) ;
  }
  @Override public void startLaunch (long n) {
    this.reset () ;
    restartLaunch (n) ;
  }
  public void restartLaunch (long n) {
    for (long i = 0 ; i < n ; i++) {
      if (generator.nextBoolean ())
        this.heads++ ;
      else
        this.tails++ ;
    }
    try {
      Thread.sleep (this.shortDelay) ;
    } catch (Exception e) { /* Just catch it! */ }
  }
  public void setShortDelay (int delay) {
    this.shortDelay = delay ;
  }
  public int getShortDelay () {
    return this.shortDelay ;
  }
  private int shortDelay ;
}